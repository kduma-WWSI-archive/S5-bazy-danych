CREATE TABLE kategorie (
  id INT PRIMARY KEY NOT NULL IDENTITY (1, 1),
  nazwa VARCHAR(75) NOT NULL
);
GO;

---~~~

DROP TABLE kategorie;
GO;