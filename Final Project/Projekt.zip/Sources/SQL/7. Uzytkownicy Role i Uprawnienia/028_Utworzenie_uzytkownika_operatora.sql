CREATE USER operator WITH PASSWORD ='yourStrong(!)Password';
GO;

---~~~

DROP USER operator;
GO;



