CREATE ROLE admini_systemu;
GO;

---~~~

DROP ROLE admini_systemu;
GO;



