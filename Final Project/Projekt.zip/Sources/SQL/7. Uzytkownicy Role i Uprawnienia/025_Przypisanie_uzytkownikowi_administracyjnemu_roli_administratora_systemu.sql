EXEC sp_addrolemember 'admini_systemu', 'admin';
GO;

---~~~

EXEC sp_droprolemember 'admini_systemu', 'admin';
GO;



