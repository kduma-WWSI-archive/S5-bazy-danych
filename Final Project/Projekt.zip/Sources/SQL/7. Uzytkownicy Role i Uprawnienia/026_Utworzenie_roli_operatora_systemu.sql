CREATE ROLE operatorzy_systemu;
GO;

---~~~

DROP ROLE operatorzy_systemu;
GO;



