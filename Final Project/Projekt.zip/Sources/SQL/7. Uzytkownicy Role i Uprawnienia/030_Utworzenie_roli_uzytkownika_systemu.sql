CREATE ROLE uzytkownicy_systemu;
GO;

---~~~

DROP ROLE uzytkownicy_systemu;
GO;



