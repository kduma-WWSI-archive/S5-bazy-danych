CREATE USER admin WITH PASSWORD ='yourStrong(!)Password';
GO;

---~~~

DROP USER admin;
GO;



