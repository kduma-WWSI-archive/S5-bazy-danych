EXEC sp_addrolemember 'operatorzy_systemu', 'operator';
GO;

---~~~

EXEC sp_droprolemember 'operatorzy_systemu', 'operator';
GO;



